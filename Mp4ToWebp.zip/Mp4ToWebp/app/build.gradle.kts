plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.mp4towebp"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.mp4towebp"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
    kotlinOptions { jvmTarget = "17" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    // Нужна сборка FFmpeg с libwebp (вариант "full"). Оригинальный ffmpeg-kit
    // закрыт и убран из Maven Central — подставьте актуальный форк.
    implementation("com.arthenica:ffmpeg-kit-full:6.0-2")
}
