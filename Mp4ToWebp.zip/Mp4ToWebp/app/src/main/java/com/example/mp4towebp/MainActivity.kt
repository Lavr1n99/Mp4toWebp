package com.example.mp4towebp

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var progress: ProgressBar
    private lateinit var pickBtn: Button
    private lateinit var fpsInput: EditText
    private lateinit var widthInput: EditText
    private lateinit var qualityInput: EditText

    private val pickVideo =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) convert(uri) else status.text = "Файл не выбран"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(pad, pad * 2, pad, pad)
        }
        fun field(hint: String, default: String) = EditText(this).apply {
            this.hint = hint; setText(default)
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
        }
        fpsInput = field("FPS", "15")
        widthInput = field("Ширина, px", "480")
        qualityInput = field("Качество 0–100", "75")
        pickBtn = Button(this).apply {
            text = "Выбрать MP4"
            setOnClickListener { pickVideo.launch("video/mp4") }
        }
        progress = ProgressBar(this).apply { visibility = android.view.View.GONE }
        status = TextView(this).apply { textSize = 16f; setPadding(0, pad, 0, 0) }

        listOf(fpsInput, widthInput, qualityInput, pickBtn, progress, status)
            .forEach { root.addView(it, LinearLayout.LayoutParams(-1, -2)) }
        setContentView(root)
    }

    private fun convert(uri: Uri) {
        val fps = fpsInput.text.toString().toIntOrNull()?.coerceIn(1, 60) ?: 15
        val width = widthInput.text.toString().toIntOrNull()?.coerceIn(16, 4096) ?: 480
        val quality = qualityInput.text.toString().toIntOrNull()?.coerceIn(0, 100) ?: 75

        setBusy(true, "Конвертация…")
        val input = File(cacheDir, "in.mp4")
        val output = File(cacheDir, "out.webp").also { it.delete() }

        Thread {
            try {
                contentResolver.openInputStream(uri)!!.use { src ->
                    input.outputStream().use { src.copyTo(it) }
                }
            } catch (e: Exception) {
                runOnUiThread { setBusy(false, "Ошибка чтения файла: ${e.message}") }
                return@Thread
            }

            val cmd = "-y -i \"${input.absolutePath}\" " +
                "-vf \"fps=$fps,scale=$width:-2:flags=lanczos\" " +
                "-c:v libwebp -lossless 0 -q:v $quality -loop 0 -an " +
                "\"${output.absolutePath}\""

            FFmpegKit.executeAsync(cmd) { session ->
                val ok = ReturnCode.isSuccess(session.returnCode) && output.exists()
                val saved = if (ok) saveToGallery(output) else null
                input.delete(); output.delete()
                runOnUiThread {
                    setBusy(
                        false,
                        if (saved != null) "Готово: Pictures/Mp4ToWebp"
                        else "Ошибка конвертации"
                    )
                }
            }
        }.start()
    }

    private fun saveToGallery(file: File): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "anim_${System.currentTimeMillis()}.webp")
            put(MediaStore.Images.Media.MIME_TYPE, "image/webp")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Mp4ToWebp")
        }
        val uri = contentResolver.insert(
            MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values
        ) ?: return null
        contentResolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        return uri
    }

    private fun setBusy(busy: Boolean, text: String) {
        progress.visibility = if (busy) android.view.View.VISIBLE else android.view.View.GONE
        pickBtn.isEnabled = !busy
        status.text = text
    }
}
